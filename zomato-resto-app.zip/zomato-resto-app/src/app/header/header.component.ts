import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  getzomatodata: any;
  establishments: any;

  constructor(private http : HttpClient) { }
users : any;
  ngOnInit(): void {
    // fetch('./assets/database/zomato.json').then(res => res.json())
    // .then(json => {
    //   this.getzomatodata = json.getzomatodata;
    //   console.log(json);
    // });


    // fetch('./assets/database/resto-category.json').then(res => res.json())
    // .then(json => {
    //   this.establishments = json.establishments;
    //   console.log(json);
    // });
  

  }

}
