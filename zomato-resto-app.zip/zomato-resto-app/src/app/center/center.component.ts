import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-center',
  templateUrl: './center.component.html',
  styleUrls: ['./center.component.css']
})
export class CenterComponent implements OnInit {
  zomato: any;
  getzomatodata: any;
  establishments: any;
  cuisines: any;

  constructor(private http : HttpClient) { }
users : any;
ngOnInit(): void {
  fetch('./assets/database/zomato.json').then(res => res.json())
  .then(json => {
    this.getzomatodata = json.getzomatodata;
    console.log(json);
  });


  fetch('./assets/database/resto-category.json').then(res => res.json())
  .then(json => {
    this.establishments = json.establishments;
    console.log(json);
  });


  fetch('./assets/database/cuisines.json').then(res => res.json())
  .then(json => {
    this.cuisines = json.cuisines;
    console.log(json);
  });

}
}
